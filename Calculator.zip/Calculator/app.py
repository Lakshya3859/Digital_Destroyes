from flask import Flask, render_template, request
import pandas as pd
import math
import matplotlib 
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import base64
from io import BytesIO


app = Flask(__name__,template_folder="templates")

def generate_plot(xList, yList, xlabel, ylabel, title):
    # Create a simple matplotlib plot
    plt.plot(xList, yList)
    plt.xlabel(xlabel, fontsize=15)
    plt.ylabel(ylabel, fontsize=15)
    plt.title(title)
    plt.grid(True)

    # Save the plot to BytesIO buffer and convert to base64
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    img_str = base64.b64encode(img.getvalue()).decode("utf-8")

    # Clear the plot for the next iteration
    plt.clf()

    return img_str

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    df = pd.read_excel("vehicle.xlsx")
    
    distance = float(request.form['distance'])
    car_name = request.form['car_name']
    s_no = int(df.loc[df["Name"]==car_name, "S. no."].iloc[0])

    road = request.form['road']
    road1 = (df.loc[df["Name"]==car_name,road])
    road2 = float(road1[s_no])

    load = request.form['load']
    load1 = (df.loc[df["Name"]==car_name,load])
    load2 = float(load1[s_no])

    speed = request.form['speed']
    speed1 = df.loc[df["Name"]==car_name,speed]
    speed2 = float(speed1[s_no])

    temp = request.form['temp']
    temp1 = df.loc[df["Name"]==car_name,temp]
    temp2 = float(temp1[s_no])

    factor = road2 + load2 + speed2 + temp2
    factor = float(factor)

    carbon_emission = ((8887 * distance) / (21.6 * 1.6)) + ((8887 * distance) / (21.6 * 1.6)) * (factor / 100) / 4
    # Create the first graph
    xList = list(range(0, 11))
    yList = [i * carbon_emission * 365 for i in xList]

    img_str = generate_plot(xList, yList, "Years", "CO2 Emissions", "CO2 Emissions vs Year")

    # Create the second graph
    xList2 = list(range(0, 11))
    yList2 = [i*i for i in xList2]

    img_str2 = generate_plot(xList2, yList2, "Years", "Chances of Increase Respiratory Infection", "Health Impact With Time")
    
    return render_template('result.html', carbon_emission=carbon_emission, img_str=img_str, img_str2=img_str2)


if __name__ == '__main__':
    app.run(debug=True)
